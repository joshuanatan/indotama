<div class="alert alert-success alert-dismissable col-lg-5 pull-right" id="notif_delete_success" style="position: fixed; top:30%;right:5%;z-index:100">
    <i class="zmdi zmdi-check pr-15 pull-left"></i><p class="pull-left">Delete <?php echo ucwords($page_title) ?> berhasil!</p> 
    <div class="clearfix"></div>
</div>