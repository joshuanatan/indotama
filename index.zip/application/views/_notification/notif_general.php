<script>
window.onload = function(e){ 
    $("#notif_register_success").css("display", "none");
    $("#notif_register_error").css("display", "none");
    $("#notif_update_success").css("display", "none");
    $("#notif_update_error").css("display", "none");
    $("#notif_delete_success").css("display", "none");
    $("#notif_delete_error").css("display", "none");
}
</script>