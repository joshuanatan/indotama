<div class="alert alert-danger alert-dismissable col-lg-11 align-self-center" id="notif_delete_error" style="position: fixed; top:50%;z-index:100;left: 50%; margin-left: -45%;">
    <i class="zmdi zmdi-alert-circle-o pr-15 pull-left"></i><p class="pull-left">Delete <?php echo ucwords($page_title) ?> gagal!</p>
    <div class="clearfix"></div>
</div>