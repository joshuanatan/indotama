<div class="alert alert-success alert-dismissable col-lg-5 pull-right position-fixed" id="notif_register_success" style="position: fixed; top:30%;right:5%;z-index:100">
    <i class="zmdi zmdi-check pr-15 pull-left"></i><p class="pull-left">Register <?php echo ucwords($page_title) ?> berhasil!</p> 
    <div class="clearfix"></div>
</div>