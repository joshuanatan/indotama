<?php
#Session required: user
?>

<li>
    <hr class="light-grey-hr mb-10" />
</li>
<li id = "general_menu_separator"></li>