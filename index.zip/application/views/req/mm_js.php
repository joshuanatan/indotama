<!-- jQuery -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/jquery/dist/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Slimscroll JavaScript -->
<script src="<?php echo base_url(); ?>asset/dist/js/jquery.slimscroll.js"></script>

<!-- Owl JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>

<!-- Switchery JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/switchery/dist/switchery.min.js"></script>

<!-- Fancy Dropdown JS -->
<script src="<?php echo base_url(); ?>asset/dist/js/dropdown-bootstrap-extended.js"></script>

<!-- Data table JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js">
</script>
<script
    src="<?php echo base_url(); ?>asset/vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js">
</script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/datatables.net-buttons/js/buttons.flash.min.js">
</script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/jszip/dist/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/pdfmake/build/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/pdfmake/build/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/datatables.net-buttons/js/buttons.html5.min.js">
</script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/datatables.net-buttons/js/buttons.print.min.js">
</script>
<script src="<?php echo base_url(); ?>asset/dist/js/export-table-data.js"></script>

<!-- simpleWeather JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/moment/min/moment.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/simpleWeather/jquery.simpleWeather.min.js">
</script>
<script src="<?php echo base_url(); ?>asset/dist/js/simpleweather-data.js"></script>

<!-- Progressbar Animation JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/jquery.counterup/jquery.counterup.min.js"></script>

<!-- Sparkline JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/jquery.sparkline/dist/jquery.sparkline.min.js"></script>
<script
    src="<?php echo base_url(); ?>asset/vendors/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js">
</script>

<!-- ChartJS JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/chart.js/Chart.min.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/chartjs-data.js"></script>

<!-- EasyPieChart JavaScript -->
<script
    src="<?php echo base_url(); ?>asset/vendors/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js">
</script>

<!-- EChartJS JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/echarts/dist/echarts-en.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/echarts-liquidfill.min.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/echart-data.js"></script>

<!-- Toast JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js">
</script>

<!-- Bootstrap Select JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/bootstrap-select/dist/js/bootstrap-select.min.js">
</script>

<!-- Init JavaScript -->
<script src="<?php echo base_url(); ?>asset/dist/js/init.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/widgets-data.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/ecommerce-data.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/dashboard2-data.js"></script>

<!-- Flot Charts JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/Flot/excanvas.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/Flot/jquery.flot.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/Flot/jquery.flot.pie.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/Flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/Flot/jquery.flot.time.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/Flot/jquery.flot.stack.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/Flot/jquery.flot.crosshair.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/flot.tooltip/js/jquery.flot.tooltip.min.js">
</script>
<script src="<?php echo base_url(); ?>asset/dist/js/flot-data.js"></script>

<!-- Progressbar Animation JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/jquery.counterup/jquery.counterup.min.js"></script>


<!-- Morris Charts JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/raphael/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/morris.js/morris.min.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/morris-data.js"></script>

<!-- Select2 JavaScript -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/select2/dist/js/select2.full.min.js"></script>

<!-- Sweet-Alert  -->
<script src="<?php echo base_url(); ?>asset/vendors/bower_components/sweetalert/dist/sweetalert.min.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/sweetalert-data.js"></script>

<!-- Gallery JavaScript -->
<script src="<?php echo base_url(); ?>asset/dist/js/isotope.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/lightgallery-all.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/froogaloop2.min.js"></script>
<script src="<?php echo base_url(); ?>asset/dist/js/gallery-data.js"></script>

<!-- Form Advance Init JavaScript -->
<script src="<?php echo base_url(); ?>asset/dist/js/form-advance-data.js"></script>