<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>Indotama Maju Mandiri</title>
<meta name="description" content="Maju Mandiri Sistem" />
<meta name="author" content="callen.id" />


<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
<!-- Data table CSS -->
<link href="<?php echo base_url(); ?>asset/vendors/bower_components/datatables/media/css/jquery.dataTables.min.css"
    rel="stylesheet" type="text/css" />
<link
    href="<?php echo base_url(); ?>asset/vendors/bower_components/datatables.net-responsive/css/responsive.dataTables.min.css"
    rel="stylesheet" type="text/css" />

<!-- select2 CSS -->
<link href="<?php echo base_url(); ?>asset/vendors/bower_components/select2/dist/css/select2.min.css" rel="stylesheet"
    type="text/css" />

<!-- Custom CSS -->
<link href="<?php echo base_url(); ?>asset/dist/css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>asset/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">


<!-- Jasny-bootstrap CSS -->
<link href="<?php echo base_url(); ?>asset/vendors/bower_components/jasny-bootstrap/dist/css/jasny-bootstrap.min.css"
    rel="stylesheet" type="text/css" />

<!-- Morris Charts CSS -->
<link href="<?php echo base_url(); ?>asset/vendors/bower_components/morris.js/morris.css" rel="stylesheet"
    type="text/css" />

<!-- Toast CSS -->
<link href="<?php echo base_url(); ?>asset/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.css"
    rel="stylesheet" type="text/css">

<!-- bootstrap-select CSS -->
<link href="<?php echo base_url(); ?>asset/vendors/bower_components/bootstrap-select/dist/css/bootstrap-select.min.css"
    rel="stylesheet" type="text/css" />

<!-- Bootstrap Switches CSS -->
<link
    href="<?php echo base_url(); ?>asset/vendors/bower_components/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.min.css"
    rel="stylesheet" type="text/css" />

<!-- switchery CSS -->
<link href="<?php echo base_url(); ?>asset/vendors/bower_components/switchery/dist/switchery.min.css" rel="stylesheet"
    type="text/css" />

<!-- Alerts CSS -->
<link href="<?php echo base_url(); ?>asset/vendors/bower_components/sweetalert/dist/sweetalert.css" rel="stylesheet"
    type="text/css">

<!-- Calendar CSS -->
<link href="<?php echo base_url(); ?>asset/vendors/bower_components/fullcalendar/dist/fullcalendar.css" rel="stylesheet"
    type="text/css" />
    
<link rel="stylesheet" href="<?php echo base_url();?>asset/dist/fonts/material-design/material-design.css">
        